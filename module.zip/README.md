# Atmosphere Switcher

Switch splash/atmosphere images on a full-scene "Landing Page" tile in one click.
Foundry VTT v13–v14, any game system.

## Use

- **Open:** GM only. Image button in the Token controls (left toolbar), or bind a key in Configure Controls.
- **First time:** window menu (⋯) → **First setup** creates the Landing Page scene and tile. Then **Change image folder** to pick your image folder (any storage, including Sqyre).
- **Hover** an image to preview it, **click** to show it to players. Star images to keep them in Favorites.
- ⋯ menu: **Refresh folders** after uploading new images, **Fade duration** (0 = instant).

First setup can create a new scene or convert an existing one. When converting, everything on the scene (tokens, walls, lights, tiles, drawings, notes, regions) is moved and scaled with it; non-16:9 scenes keep their proportions and get black space around them. A backup copy is made first unless you untick it.

Images always fill the tile and are trimmed if their shape differs; they are never stretched.

## Lock View

First setup turns on Pan Lock, Zoom Lock and Autoscale "Automatic Fit (Inside)" for the Landing Page.
Lock View only affects users enabled in its **User Configurator**: enable your players there once.

## Macro / API

```js
game.modules.get("atmosphere-switcher").api.open();
game.modules.get("atmosphere-switcher").api.show("path/to/image.webp");
```
