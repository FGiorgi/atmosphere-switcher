/**
 * Atmosphere Switcher — switch splash images on a full-scene "Landing Page" tile.
 * Foundry VTT v13–v14, system agnostic.
 */

const ID = "atmosphere-switcher";
const SOCKET = `module.${ID}`;
const SCENE_W = 3840;
const SCENE_H = 2160;
const MAX_DEPTH = 8;
const MAX_RECENT = 10;
const MAX_SEARCH = 200;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const FP = () => foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
const DialogV2 = () => foundry.applications.api.DialogV2;
const loadTex = (src) => (foundry.canvas?.loadTexture ?? globalThis.loadTexture)(src);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const setting = (key) => game.settings.get(ID, key);
const setSetting = (key, value) => game.settings.set(ID, key, value);

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function decode(s) {
  try { return decodeURIComponent(s); } catch { return s; }
}

function trimPath(p) {
  return String(p ?? "").replace(/\/+$/, "");
}

function lastSegment(p) {
  return decode(trimPath(p).split("?")[0].split("/").pop() ?? "");
}

function prettyName(src) {
  const base = lastSegment(src).replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
  return base ? base.charAt(0).toUpperCase() + base.slice(1) : "(unnamed)";
}

let IMAGE_EXT = new Set(["apng", "avif", "bmp", "gif", "jpeg", "jpg", "png", "svg", "tiff", "webp"]);
function isImage(src) {
  const ext = String(src).split("?")[0].split(".").pop().toLowerCase();
  return IMAGE_EXT.has(ext);
}

const byName = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });

/* ------------------------------------------------------------------ */
/* Image library (folder walk, cached per session)                    */
/* ------------------------------------------------------------------ */

const Library = {
  root: null,          // tree node
  byPath: new Map(),   // path -> node
  bySrc: new Map(),    // src -> { src, name, folder }
  all: [],             // flat list of files
  loading: null,       // Promise while walking
  error: null,

  reset() {
    this.root = null; this.byPath = new Map(); this.bySrc = new Map(); this.all = []; this.loading = null; this.error = null;
  },

  rootConfig() {
    return { source: setting("rootSource") || "data", path: trimPath(setting("rootPath")), options: setting("rootOptions") || {} };
  },

  async browse(path) {
    const { source, options } = this.rootConfig();
    return FP().browse(source, path, { ...options });
  },

  async walk(path, depth = 0) {
    const node = { path, name: lastSegment(path) || "Images", dirs: [], files: [], total: 0, depth };
    let res;
    try {
      res = await this.browse(path);
    } catch (err) {
      console.warn(`${ID} | could not browse "${path}"`, err);
      if (depth === 0) throw err;
      return node;
    }
    node.files = (res.files ?? []).filter(isImage).map((src) => ({ src, name: prettyName(src), folder: path })).sort(byName);
    if (depth < MAX_DEPTH) {
      const dirs = (res.dirs ?? []).map(trimPath).filter((d) => d && d !== trimPath(path));
      node.dirs = (await Promise.all(dirs.map((d) => this.walk(d, depth + 1)))).sort(byName);
    }
    node.total = node.files.length + node.dirs.reduce((sum, d) => sum + d.total, 0);
    return node;
  },

  index(node, parent = null) {
    node.parent = parent?.path ?? null;
    this.byPath.set(node.path, node);
    for (const f of node.files) { this.bySrc.set(f.src, f); this.all.push(f); }
    for (const d of node.dirs) this.index(d, node);
  },

  ancestors(path) {
    const out = [];
    let node = this.byPath.get(path);
    while (node?.parent) { out.unshift(node.parent); node = this.byPath.get(node.parent); }
    return out;
  },

  async load() {
    if (this.loading) return this.loading;
    const { path } = this.rootConfig();
    if (!path) return null;
    this.loading = (async () => {
      try {
        const root = await this.walk(path, 0);
        this.byPath = new Map(); this.bySrc = new Map(); this.all = [];
        this.index(root);
        this.root = root;
        this.error = null;
      } catch (err) {
        this.error = err?.message ?? String(err);
      } finally {
        this.loading = null;
      }
      return this.root;
    })();
    return this.loading;
  },

  nameOf(src) {
    return this.bySrc.get(src)?.name ?? prettyName(src);
  }
};

/* ------------------------------------------------------------------ */
/* Landing Page tile                                                   */
/* ------------------------------------------------------------------ */

function getTile() {
  const uuid = setting("tileUuid");
  let tile = null;
  if (uuid) {
    try { tile = fromUuidSync(uuid); } catch { tile = null; }
  }
  if (!tile) {
    for (const scene of game.scenes) {
      const t = scene.tiles.find((x) => x.getFlag(ID, "atmosphere"));
      if (t) { tile = t; break; }
    }
  }
  return tile?.documentName === "Tile" ? tile : null;
}

function liveSrc() {
  return getTile()?.texture?.src ?? null;
}

async function pushRecent(src) {
  const recent = [src, ...(setting("recent") ?? []).filter((s) => s !== src)].slice(0, MAX_RECENT);
  await setSetting("recent", recent);
}

async function toggleFavorite(src) {
  const favs = setting("favorites") ?? [];
  await setSetting("favorites", favs.includes(src) ? favs.filter((s) => s !== src) : [...favs, src]);
}

let showing = false;
async function showImage(src) {
  if (!game.user.isGM || !src || showing) return;
  const tile = getTile();
  if (!tile) {
    ui.notifications.warn("Atmosphere: no Landing Page yet. Open the ⋯ menu and run First setup.");
    return;
  }
  if (tile.texture?.src === src) return;
  showing = true;
  try {
    const duration = Math.max(0, Number(setting("fadeMs")) || 0);
    pushRecent(src);
    if (duration > 0) {
      const msg = { type: "fadeOut", tileUuid: tile.uuid, src, duration };
      game.socket.emit(SOCKET, msg);
      Fader.fadeOut(msg);
      await sleep(duration / 2);
    } else {
      loadTex(src).catch(() => {});
    }
    await tile.update({ "texture.src": src }, { [ID]: { fade: duration } });
  } catch (err) {
    console.error(`${ID} | failed to show image`, err);
    ui.notifications.error("Atmosphere: could not change the image. See the console (F12).");
  } finally {
    showing = false;
  }
}

/* ------------------------------------------------------------------ */
/* Dip-to-black fade, run locally on every client                      */
/* ------------------------------------------------------------------ */

const Fader = {
  states: new Map(), // tileId -> { alpha, raf, preload, timeout }

  placeable(tileId) {
    if (!canvas?.ready) return null;
    return canvas.tiles?.get(tileId) ?? null;
  },

  apply(tileId) {
    const st = this.states.get(tileId);
    const t = this.placeable(tileId);
    if (st && t?.mesh) t.mesh.alpha = st.alpha;
  },

  tween(tileId, to, ms, done) {
    const st = this.states.get(tileId);
    if (!st) return;
    if (st.raf) cancelAnimationFrame(st.raf);
    const from = st.alpha;
    const start = performance.now();
    const step = (now) => {
      const k = ms > 0 ? Math.min(1, (now - start) / ms) : 1;
      const eased = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      st.alpha = from + (to - from) * eased;
      this.apply(tileId);
      if (k < 1) st.raf = requestAnimationFrame(step);
      else { st.raf = null; done?.(); }
    };
    st.raf = requestAnimationFrame(step);
  },

  fadeOut({ tileUuid, src, duration }) {
    const preload = loadTex(src).catch(() => null);
    let doc = null;
    try { doc = fromUuidSync(tileUuid); } catch { doc = null; }
    if (!doc || doc.parent?.id !== canvas?.scene?.id) return;
    const t = this.placeable(doc.id);
    if (!t?.mesh) return;
    const old = this.states.get(doc.id);
    if (old?.raf) cancelAnimationFrame(old.raf);
    if (old?.timeout) clearTimeout(old.timeout);
    const st = { alpha: t.mesh.alpha ?? 1, raf: null, preload, timeout: null };
    this.states.set(doc.id, st);
    this.tween(doc.id, 0, duration / 2);
    // Safety: never leave the tile dark if the update never arrives.
    st.timeout = setTimeout(() => this.finish(doc.id), duration + 5000);
  },

  async fadeIn(tileId, duration) {
    const st = this.states.get(tileId);
    if (!st) return;
    if (st.timeout) clearTimeout(st.timeout);
    st.timeout = setTimeout(() => this.finish(tileId), duration + 5000);
    await st.preload;
    await sleep(60); // let the tile redraw with the new texture
    this.tween(tileId, 1, duration / 2, () => this.finish(tileId));
  },

  finish(tileId) {
    const st = this.states.get(tileId);
    if (!st) return;
    if (st.raf) cancelAnimationFrame(st.raf);
    if (st.timeout) clearTimeout(st.timeout);
    this.states.delete(tileId);
    const t = this.placeable(tileId);
    if (t) t.renderFlags?.set({ refreshState: true });
  }
};

/* ------------------------------------------------------------------ */
/* Hover preview (floats beside the window)                           */
/* ------------------------------------------------------------------ */

const Hover = {
  el: null,
  ensure() {
    if (this.el) return this.el;
    const el = document.createElement("div");
    el.className = "atm-hover";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML = `<div class="atm-hover-frame"><img alt=""></div><div class="atm-hover-cap"><strong></strong><span></span></div>`;
    document.body.appendChild(el);
    this.el = el;
    return el;
  },
  show(src, name, folder, appEl) {
    if (!appEl) return;
    const el = this.ensure();
    const img = el.querySelector("img");
    if (img.getAttribute("src") !== src) img.setAttribute("src", src);
    el.querySelector("strong").textContent = name;
    el.querySelector("span").textContent = decode(folder ?? "");
    const r = appEl.getBoundingClientRect();
    const w = 400, h = 270, gap = 12;
    let left = r.left - w - gap;
    if (left < 8) left = Math.min(window.innerWidth - w - 8, r.right + gap);
    const top = Math.max(8, Math.min(window.innerHeight - h - 8, r.top));
    el.style.left = `${left}px`;
    el.style.top = `${top}px`;
    el.classList.add("visible");
  },
  hide() {
    this.el?.classList.remove("visible");
  }
};

/* ------------------------------------------------------------------ */
/* First setup                                                         */
/* ------------------------------------------------------------------ */

const LOCKVIEW_DEFAULT = {
  locks: { pan: false, zoom: false, boundingBox: false },
  ui: { hideOn: "off", "scene-controls": false, hotbar: false, "scene-navigation": false, players: false, sidebar: false, "chat-notifications": false, "camera-views": false },
  sidebar: { sceneLoad: "noChange", exclude: false, blacken: false },
  avDock: { sceneLoad: "noChange", exclude: false, blacken: false },
  autoscale: "off",
  forceInitialView: false
};

async function configureLockView(scene) {
  const lv = game.modules.get("LockView");
  if (!lv?.active) return "missing";
  const major = parseInt(String(lv.version ?? "0"), 10) || 0;
  if (major >= 2) {
    let worldDefault = {};
    try { worldDefault = game.settings.get("LockView", "defaultSceneConfig") ?? {}; } catch { worldDefault = {}; }
    const builtIn = globalThis.lockView?.sceneHandler?.defaultSceneConfig ?? LOCKVIEW_DEFAULT;
    let cfg = foundry.utils.mergeObject(foundry.utils.deepClone(LOCKVIEW_DEFAULT), foundry.utils.deepClone(builtIn), { inplace: false });
    cfg = foundry.utils.mergeObject(cfg, foundry.utils.deepClone(worldDefault), { inplace: false });
    if (scene.flags?.LockView?.locks) cfg = foundry.utils.mergeObject(cfg, foundry.utils.deepClone(scene.flags.LockView), { inplace: false });
    cfg.locks = { ...cfg.locks, pan: true, zoom: true };
    cfg.autoscale = "autoInside";
    await scene.update({ "flags.LockView": cfg });
  } else {
    await scene.update({ "flags.LockView": { lockPan: true, lockZoom: true, lockPanInit: true, lockZoomInit: true, autoScale: 3 } });
  }
  return "ok";
}

/**
 * Lowest sort/elevation among the scene's tiles, ignoring the given ids.
 */
function bottomOfStack(scene, ignore = []) {
  let sort = 0;
  let elevation = 0;
  for (const t of scene.tiles) {
    if (ignore.includes(t.id)) continue;
    sort = Math.min(sort, (t.sort ?? 0) - 1);
    elevation = Math.min(elevation, t.elevation ?? 0);
  }
  return { sort, elevation };
}

/* ---------- scene background (v13: on the scene, v14: on its first level) ---------- */

function backgroundLevel(scene) {
  return scene.initialLevel ?? scene.firstLevel ?? scene.levels?.contents?.[0] ?? null;
}

function getBackgroundSrc(scene) {
  const level = backgroundLevel(scene);
  if (level?.background) return level.background.src ?? null;
  return scene._source?.background?.src ?? scene.background?.src ?? null;
}

async function clearBackground(scene) {
  const level = backgroundLevel(scene);
  if (level?.background && typeof level.update === "function") return level.update({ "background.src": null });
  return scene.update({ "background.src": null });
}

/* ---------- resize an existing scene and move everything with it ---------- */

/**
 * Resizes the scene to 3840×2160 keeping proportions. Content is scaled evenly and centred;
 * non-16:9 scenes get black space around them. Returns a summary.
 */
async function resizeSceneKeepingContent(scene) {
  const old = scene.dimensions;
  const oldX = old.sceneX, oldY = old.sceneY, oldW = old.sceneWidth, oldH = old.sceneHeight;
  const gridless = scene.grid?.type === CONST.GRID_TYPES.GRIDLESS;
  const oldGrid = scene.grid?.size ?? 100;

  // Uniform scale that fits inside 3840×2160. On gridded scenes, snap so the new grid size is a whole number.
  let s = Math.min(SCENE_W / oldW, SCENE_H / oldH);
  let newGrid = oldGrid;
  if (!gridless) {
    const minGrid = CONST.GRID_MIN_SIZE ?? 20;
    newGrid = Math.max(minGrid, Math.floor(oldGrid * s));
    s = newGrid / oldGrid;
  }
  const isSixteenNine = Math.abs(oldW / oldH - SCENE_W / SCENE_H) < 0.01;
  if (Math.abs(s - 1) < 1e-6 && oldW === SCENE_W && oldH === SCENE_H) return { scaled: false, convertedBackground: false };

  const contentW = oldW * s;
  const contentH = oldH * s;
  // Centre the content; on gridded scenes keep the offset on the grid so grid and map stay aligned.
  let offX = (SCENE_W - contentW) / 2;
  let offY = (SCENE_H - contentH) / 2;
  if (!gridless) { offX = Math.floor(offX / newGrid) * newGrid; offY = Math.floor(offY / newGrid) * newGrid; }

  const bgSrc = getBackgroundSrc(scene);
  const initial = scene.initial ?? scene._source?.initial;

  const sceneUpdate = { width: SCENE_W, height: SCENE_H };
  if (!gridless) sceneUpdate["grid.size"] = newGrid;
  await scene.update(sceneUpdate);

  const nd = scene.dimensions;
  const cx = nd.sceneX + offX;
  const cy = nd.sceneY + offY;
  const P = (x, y) => [Math.round(cx + (x - oldX) * s), Math.round(cy + (y - oldY) * s)];
  const L = (v) => Math.round(v * s);

  if (initial && Number.isFinite(initial.x) && Number.isFinite(initial.y)) {
    const [ix, iy] = P(initial.x, initial.y);
    await scene.update({ "initial.x": ix, "initial.y": iy });
  }

  const batches = {};
  const add = (type, data) => (batches[type] ??= []).push(data);

  for (const t of scene.tokens ?? []) { const [x, y] = P(t.x, t.y); add("Token", { _id: t.id, x, y }); }
  for (const t of scene.tiles ?? []) {
    if (t.getFlag(ID, "atmosphere")) continue;
    const [x, y] = P(t.x, t.y);
    add("Tile", { _id: t.id, x, y, width: L(t.width), height: L(t.height) });
  }
  for (const w of scene.walls ?? []) {
    const [x1, y1] = P(w.c[0], w.c[1]); const [x2, y2] = P(w.c[2], w.c[3]);
    add("Wall", { _id: w.id, c: [x1, y1, x2, y2] });
  }
  for (const l of scene.lights ?? []) { const [x, y] = P(l.x, l.y); add("AmbientLight", { _id: l.id, x, y }); }
  for (const a of scene.sounds ?? []) { const [x, y] = P(a.x, a.y); add("AmbientSound", { _id: a.id, x, y }); }
  for (const n of scene.notes ?? []) { const [x, y] = P(n.x, n.y); add("Note", { _id: n.id, x, y }); }
  for (const m of scene.templates ?? []) { const [x, y] = P(m.x, m.y); add("MeasuredTemplate", { _id: m.id, x, y }); }
  for (const d of scene.drawings ?? []) {
    const [x, y] = P(d.x, d.y);
    const upd = { _id: d.id, x, y, "shape.width": L(d.shape?.width ?? 0), "shape.height": L(d.shape?.height ?? 0) };
    if (Array.isArray(d.shape?.points) && d.shape.points.length) upd["shape.points"] = d.shape.points.map((v) => L(v));
    if (d.fontSize) upd.fontSize = Math.max(8, L(d.fontSize));
    add("Drawing", upd);
  }
  let skippedShapes = 0;
  for (const r of scene.regions ?? []) {
    const shapes = (r.shapes ?? []).map((sh) => {
      const o = typeof sh.toObject === "function" ? sh.toObject() : { ...sh };
      switch (o.type) {
        case "rectangle": { const [x, y] = P(o.x, o.y); return { ...o, x, y, width: L(o.width), height: L(o.height) }; }
        case "circle": { const [x, y] = P(o.x, o.y); return { ...o, x, y, radius: L(o.radius) }; }
        case "ellipse": { const [x, y] = P(o.x, o.y); return { ...o, x, y, radiusX: L(o.radiusX), radiusY: L(o.radiusY) }; }
        case "polygon": {
          const pts = [];
          for (let i = 0; i < (o.points?.length ?? 0); i += 2) pts.push(...P(o.points[i], o.points[i + 1]));
          return { ...o, points: pts };
        }
        default: skippedShapes++; return o;
      }
    });
    add("Region", { _id: r.id, shapes });
  }

  for (const [type, updates] of Object.entries(batches)) {
    if (!updates.length) continue;
    try {
      await scene.updateEmbeddedDocuments(type, updates, { animate: false });
    } catch (err) {
      console.warn(`${ID} | could not reposition ${type}`, err);
    }
  }

  // Foundry stretches the scene background to fill the scene. For non-16:9 scenes, keep the map's
  // proportions by turning the background into a tile placed exactly where the map now sits.
  let convertedBackground = false;
  if (bgSrc && !isSixteenNine) {
    await scene.createEmbeddedDocuments("Tile", [{
      x: Math.round(cx), y: Math.round(cy), width: Math.round(contentW), height: Math.round(contentH),
      texture: { src: bgSrc, fit: "fill" },
      locked: true, hidden: false, alpha: 1,
      flags: { [ID]: { formerBackground: true } }
    }]);
    await clearBackground(scene);
    convertedBackground = true;
  }
  if (skippedShapes) console.warn(`${ID} | ${skippedShapes} region shape(s) of an unknown type were left in place`);
  return { scaled: true, convertedBackground };
}

/**
 * @param {object} opts
 * @param {"new"|"existing"} opts.mode
 * @param {string} [opts.sceneId]   scene to convert when mode is "existing"
 * @param {boolean} [opts.resize]   resize an existing scene to 3840×2160, moving its contents with it
 * @param {boolean} [opts.backup]   duplicate the existing scene first
 * @param {boolean} [opts.activate]
 */
async function runSetup({ mode = "new", sceneId = null, resize = true, backup = true, activate = false } = {}) {
  let scene;
  let backupScene = null;
  let resized = { scaled: false, convertedBackground: false };

  if (mode === "existing") {
    scene = game.scenes.get(sceneId);
    if (!scene) throw new Error("Selected scene not found.");
    if (backup) {
      backupScene = await scene.clone({ name: `${scene.name} (backup)`, active: false, navigation: false }, { save: true });
      if (backupScene?.getFlag(ID, "landing")) await backupScene.unsetFlag(ID, "landing");
      const flagged = backupScene?.tiles?.filter((t) => t.getFlag(ID, "atmosphere")) ?? [];
      if (flagged.length) await backupScene.deleteEmbeddedDocuments("Tile", flagged.map((t) => t.id));
    }
    if (resize) resized = await resizeSceneKeepingContent(scene);
    // Only the setup steps are touched; everything else stays as it is.
    await scene.update({ backgroundColor: "#000000", tokenVision: false, [`flags.${ID}.landing`]: true });
  } else {
    scene = await Scene.implementation.create({
      name: "Landing Page",
      width: SCENE_W,
      height: SCENE_H,
      padding: 0,
      backgroundColor: "#000000",
      tokenVision: false,
      grid: { type: CONST.GRID_TYPES.GRIDLESS },
      flags: { [ID]: { landing: true } }
    });
  }

  // Only one Landing Page is linked to the tool at a time.
  for (const other of game.scenes) {
    if (other.id !== scene.id && other.getFlag(ID, "landing")) await other.unsetFlag(ID, "landing");
  }

  const d = scene.dimensions;
  const rect = {
    x: d?.sceneX ?? 0,
    y: d?.sceneY ?? 0,
    width: d?.sceneWidth ?? SCENE_W,
    height: d?.sceneHeight ?? SCENE_H
  };

  // Stack order (bottom → top): former background tile, atmosphere tile, every other tile.
  let tile = scene.tiles.find((t) => t.getFlag(ID, "atmosphere"));
  const formerBg = scene.tiles.find((t) => t.getFlag(ID, "formerBackground"));
  const bottom = bottomOfStack(scene, [tile?.id, formerBg?.id].filter(Boolean));
  if (formerBg) await formerBg.update({ sort: bottom.sort - 1, elevation: bottom.elevation });
  if (tile) {
    await tile.update({ ...rect, ...bottom, locked: true, hidden: false, alpha: 1, "texture.fit": "cover", "texture.scaleX": 1, "texture.scaleY": 1 });
  } else {
    [tile] = await scene.createEmbeddedDocuments("Tile", [{
      ...rect,
      ...bottom,
      locked: true,
      hidden: false,
      alpha: 1,
      texture: { src: null, fit: "cover", scaleX: 1, scaleY: 1 },
      flags: { [ID]: { atmosphere: true } }
    }]);
  }
  await setSetting("tileUuid", tile.uuid);

  const lockView = await configureLockView(scene);
  if (activate) await scene.activate();
  return { scene, tile, lockView, backupScene, resized };
}

/* ------------------------------------------------------------------ */
/* The window                                                          */
/* ------------------------------------------------------------------ */

const { ApplicationV2 } = foundry.applications.api;

class AtmosphereApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "atmosphere-switcher",
    classes: ["atmosphere-switcher"],
    window: {
      title: "Atmosphere",
      icon: "fa-solid fa-image",
      resizable: true,
      controls: [
        { action: "setup", icon: "fa-solid fa-wand-magic-sparkles", label: "First setup…" },
        { action: "chooseFolder", icon: "fa-solid fa-folder-open", label: "Change image folder…" },
        { action: "refresh", icon: "fa-solid fa-rotate", label: "Refresh folders" },
        { action: "fade", icon: "fa-solid fa-circle-half-stroke", label: "Fade duration…" }
      ]
    },
    position: { width: 421, height: 226 },
    actions: {
      setup: AtmosphereApp.onSetup,
      chooseFolder: AtmosphereApp.onChooseFolder,
      refresh: AtmosphereApp.onRefresh,
      fade: AtmosphereApp.onFade,
      folder: AtmosphereApp.onFolder,
      toggle: AtmosphereApp.onToggle,
      show: AtmosphereApp.onShow,
      favorite: AtmosphereApp.onFavorite
    }
  };

  static get instance() {
    return foundry.applications.instances?.get("atmosphere-switcher") ?? null;
  }

  static toggle() {
    const app = AtmosphereApp.instance;
    if (app?.rendered) return app.close();
    return new AtmosphereApp().render({ force: true });
  }

  constructor(options = {}) {
    const saved = game.settings.get(ID, "windowPos") ?? {};
    const position = {};
    for (const k of ["left", "top", "width", "height"]) if (Number.isFinite(saved[k])) position[k] = saved[k];
    super(foundry.utils.mergeObject({ position }, options, { inplace: false }));
    this.folder = null;     // selected folder path, "__favs" or "__recent"
    this.query = "";
    this.searchFocused = false;
  }

  /* ---------- rendering ---------- */

  async _renderHTML() {
    const { path } = Library.rootConfig();
    if (!path) return this.#emptyRootHTML();
    if (!Library.root && !Library.loading && !Library.error) {
      Library.load().then(() => this.rendered && this.render());
    }
    if (Library.error && !Library.root) return this.#messageHTML(`Could not read the image folder.<br><small>${esc(Library.error)}</small>`, true);
    if (!Library.root) return this.#messageHTML(`<i class="fa-solid fa-spinner fa-spin"></i> Reading folders…`, false);

    if (!this.folder || (!this.folder.startsWith("__") && !Library.byPath.has(this.folder))) this.folder = Library.root.path;
    return `<div class="atm-root">${this.#navHTML()}${this.#mainHTML()}</div>`;
  }

  _replaceHTML(result, content) {
    content.innerHTML = result;
  }

  _onRender(context, options) {
    super._onRender?.(context, options);
    const el = this.element;
    const search = el.querySelector(".atm-search");
    if (search) {
      search.addEventListener("input", (ev) => {
        this.query = ev.currentTarget.value;
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => this.render(), 120);
      });
      search.addEventListener("focus", () => { this.searchFocused = true; });
      search.addEventListener("blur", () => { this.searchFocused = false; });
      if (this.searchFocused) {
        search.focus();
        const n = search.value.length;
        search.setSelectionRange(n, n);
      }
    }
    for (const row of el.querySelectorAll(".atm-item")) {
      row.addEventListener("mouseenter", () => Hover.show(row.dataset.src, row.dataset.name, row.dataset.folder, el));
      row.addEventListener("mouseleave", () => Hover.hide());
    }
    el.querySelector(".atm-list")?.addEventListener("scroll", () => Hover.hide(), { passive: true });
  }

  async _onClose(options) {
    Hover.hide();
    const { left, top, width, height } = this.position ?? {};
    game.settings.set(ID, "windowPos", { left, top, width, height });
    return super._onClose?.(options);
  }

  #emptyRootHTML() {
    return `<div class="atm-message">
      <p>Choose the folder that holds your atmosphere images.</p>
      <button type="button" data-action="chooseFolder"><i class="fa-solid fa-folder-open"></i> Choose folder</button>
      ${getTile() ? "" : `<button type="button" class="atm-secondary" data-action="setup"><i class="fa-solid fa-wand-magic-sparkles"></i> First setup</button>`}
    </div>`;
  }

  #messageHTML(html, withButton) {
    return `<div class="atm-message"><p>${html}</p>${withButton ? `<button type="button" data-action="chooseFolder">Change folder</button>` : ""}</div>`;
  }

  #navHTML() {
    const favs = setting("favorites") ?? [];
    const recent = setting("recent") ?? [];
    const expanded = new Set(game.settings.get(ID, "expanded") ?? []);
    expanded.add(Library.root.path);
    // Always show the selected folder's ancestors.
    if (!this.folder.startsWith("__")) for (const p of Library.ancestors(this.folder)) expanded.add(p);
    const active = (key) => (!this.query && this.folder === key ? " active" : "");
    const rows = [];
    const walk = (node, depth) => {
      const hasKids = node.dirs.length > 0;
      const open = expanded.has(node.path);
      rows.push(`<div class="atm-tree-row" style="--depth:${depth}">
        ${hasKids
          ? `<button type="button" class="atm-twist${open ? " open" : ""}" data-action="toggle" data-path="${esc(node.path)}" aria-label="${open ? "Collapse" : "Expand"} ${esc(node.name)}" aria-expanded="${open}"><i class="fa-solid fa-chevron-right"></i></button>`
          : `<span class="atm-twist-spacer"></span>`}
        <button type="button" class="atm-row${active(node.path)}" data-action="folder" data-path="${esc(node.path)}">
          <i class="fa-solid fa-folder"></i><span class="atm-label">${esc(node.name)}</span><span class="atm-count">${node.total}</span>
        </button>
      </div>`);
      if (hasKids && open) for (const d of node.dirs) walk(d, depth + 1);
    };
    walk(Library.root, 0);

    return `<nav class="atm-nav" aria-label="Image folders">
      <label class="atm-search-wrap"><i class="fa-solid fa-magnifying-glass"></i>
        <input class="atm-search" type="search" placeholder="Search" aria-label="Search all images" value="${esc(this.query)}">
      </label>
      <button type="button" class="atm-row${active("__favs")}" data-action="folder" data-path="__favs"><i class="fa-solid fa-star atm-star-on"></i><span class="atm-label">Favorites</span><span class="atm-count">${favs.length}</span></button>
      <button type="button" class="atm-row${active("__recent")}" data-action="folder" data-path="__recent"><i class="fa-regular fa-clock"></i><span class="atm-label">Recent</span><span class="atm-count">${recent.length}</span></button>
      <hr>
      ${rows.join("")}
    </nav>`;
  }

  #mainHTML() {
    const favs = new Set(setting("favorites") ?? []);
    const live = liveSrc();
    const q = this.query.trim().toLowerCase();
    let title = "";
    let items = [];
    let pills = [];
    let empty = "";

    if (q) {
      items = Library.all.filter((f) => f.name.toLowerCase().includes(q)).slice(0, MAX_SEARCH);
      title = `Search: ${items.length}${items.length === MAX_SEARCH ? "+" : ""} found`;
      if (!items.length) empty = `No images match “${esc(this.query)}”.`;
    } else if (this.folder === "__favs") {
      items = [...favs].map((src) => Library.bySrc.get(src) ?? { src, name: prettyName(src), folder: "" });
      title = "Favorites";
      if (!items.length) empty = "Star an image to keep it here.";
    } else if (this.folder === "__recent") {
      items = (setting("recent") ?? []).map((src) => Library.bySrc.get(src) ?? { src, name: prettyName(src), folder: "" });
      title = "Recent";
      if (!items.length) empty = "Images you show will appear here.";
    } else {
      const node = Library.byPath.get(this.folder) ?? Library.root;
      items = node.files;
      pills = node.dirs;
      const chain = [...Library.ancestors(node.path).slice(1), node.path].filter((p) => p !== Library.root.path);
      title = chain.length ? chain.map((p) => Library.byPath.get(p)?.name ?? lastSegment(p)).join(" › ") : Library.root.name;
      if (!items.length) empty = pills.length ? "Pick a subfolder above." : "No images in this folder.";
    }

    const pillHTML = pills.map((d) => `<button type="button" class="atm-pill" data-action="folder" data-path="${esc(d.path)}"><i class="fa-solid fa-folder"></i>${esc(d.name)} <span>${d.total}</span></button>`).join("");

    const rows = items.map((f) => {
      const isLive = f.src === live;
      const isFav = favs.has(f.src);
      return `<li class="atm-item${isLive ? " live" : ""}" data-src="${esc(f.src)}" data-name="${esc(f.name)}" data-folder="${esc(f.folder)}">
        <button type="button" class="atm-show" data-action="show" data-src="${esc(f.src)}" aria-label="Show ${esc(f.name)} to players">
          <span class="atm-thumb"><img src="${esc(f.src)}" alt="" loading="lazy" decoding="async"></span>
          <span class="atm-name">${esc(f.name)}</span>
          ${isLive ? `<span class="atm-live">LIVE</span>` : ""}
        </button>
        <button type="button" class="atm-fav${isFav ? " on" : ""}" data-action="favorite" data-src="${esc(f.src)}" aria-label="${isFav ? "Remove from" : "Add to"} favorites" aria-pressed="${isFav}">
          <i class="${isFav ? "fa-solid" : "fa-regular"} fa-star"></i>
        </button>
      </li>`;
    }).join("");

    const tile = getTile();
    const foot = tile
      ? `<span class="atm-dot"></span><span class="atm-foot-name">${live ? esc(Library.nameOf(live)) : "Nothing shown yet"}</span><span class="atm-foot-hint">hover to preview, click to show</span>`
      : `<span class="atm-foot-warn">No Landing Page yet.</span><button type="button" class="atm-link" data-action="setup">Run first setup</button>`;

    return `<section class="atm-main" aria-label="Images">
      <div class="atm-crumbs"><strong>${esc(title)}</strong>${pillHTML}</div>
      <ol class="atm-list">${rows}${empty ? `<li class="atm-empty">${empty}</li>` : ""}</ol>
      <footer class="atm-foot">${foot}</footer>
    </section>`;
  }

  /* ---------- actions (this = app) ---------- */

  static async onShow(event, target) {
    Hover.hide();
    await showImage(target.dataset.src);
  }

  static async onFavorite(event, target) {
    await toggleFavorite(target.dataset.src);
    this.render();
  }

  static onFolder(event, target) {
    this.folder = target.dataset.path;
    this.query = "";
    this.searchFocused = false;
    this.render();
  }

  static async onToggle(event, target) {
    const path = target.dataset.path;
    const expanded = new Set(game.settings.get(ID, "expanded") ?? []);
    if (expanded.has(path)) {
      expanded.delete(path);
      // collapsing a parent of the selection moves the selection up
      if (this.folder && Library.ancestors(this.folder).includes(path)) this.folder = path;
    } else expanded.add(path);
    await game.settings.set(ID, "expanded", [...expanded]);
    this.render();
  }

  static async onRefresh() {
    Library.reset();
    this.render();
  }

  static onChooseFolder() {
    const app = this;
    const { source, path } = Library.rootConfig();
    const picker = new (FP())({
      type: "folder",
      current: path || "",
      activeSource: setting("rootSource") || undefined,
      callback: async (picked, fp) => {
        const src = fp?.activeSource ?? source ?? "data";
        const bucket = fp?.sources?.[src]?.bucket;
        await setSetting("rootSource", src);
        await setSetting("rootPath", trimPath(picked));
        await setSetting("rootOptions", bucket ? { bucket } : {});
        Library.reset();
        app.folder = null;
        app.render({ force: true });
      }
    });
    picker.render({ force: true });
  }

  static async onFade() {
    const current = Number(setting("fadeMs")) || 0;
    const value = await DialogV2().prompt({
      window: { title: "Fade duration" },
      content: `<div class="form-group"><label>Milliseconds (0 = instant change)</label>
        <input type="number" name="ms" min="0" max="5000" step="100" value="${current}" autofocus></div>`,
      ok: { label: "Save", callback: (event, button) => button.form.elements.ms.valueAsNumber },
      rejectClose: false
    });
    if (Number.isFinite(value)) await setSetting("fadeMs", Math.max(0, Math.min(5000, Math.round(value))));
  }

  static async onSetup() {
    const linked = game.scenes.find((s) => s.getFlag(ID, "landing"));
    const scenes = [...game.scenes].sort((a, b) => a.name.localeCompare(b.name));
    const lv = game.modules.get("LockView");
    const lockLine = lv?.active
      ? "Pan Lock on, Zoom Lock on, Autoscale: Automatic Fit (Inside)."
      : "<em>Lock View is not active, so this step will be skipped.</em>";
    const options = scenes.map((s) => `<option value="${s.id}" ${s.id === (linked?.id ?? canvas?.scene?.id) ? "selected" : ""}>${esc(s.name)}</option>`).join("");
    const content = `<div class="atm-setup">
      <fieldset class="atm-modes">
        <label class="atm-check"><input type="radio" name="mode" value="new" ${linked ? "" : "checked"}> Create a new scene “Landing Page”</label>
        <label class="atm-check"><input type="radio" name="mode" value="existing" ${linked ? "checked" : ""} ${scenes.length ? "" : "disabled"}> Use an existing scene</label>
        <div class="atm-existing">
          <select name="sceneId" aria-label="Scene to use">${options}</select>
          <label class="atm-check"><input type="checkbox" name="resize" checked> Resize it to ${SCENE_W} × ${SCENE_H}</label>
          <label class="atm-check"><input type="checkbox" name="backup" checked> Make a backup copy first</label>
          <p class="atm-note">Tokens, walls, lights, tiles, drawings, notes and regions are moved and scaled with the scene, so they stay in place on the map. Scenes that aren't 16:9 keep their proportions and get black space around them. All other settings are kept.</p>
        </div>
      </fieldset>
      <ul>
        <li><strong>Scene</strong>: ${SCENE_W} × ${SCENE_H} px (16:9), black background, no padding (new scene)</li>
        <li><strong>Token vision off</strong></li>
        <li><strong>Full-scene tile</strong>: empty for now, locked, below everything else. Images fill it and are trimmed if needed, never stretched.</li>
        <li><strong>Lock View</strong>: ${lockLine}</li>
      </ul>
      <label class="atm-check"><input type="checkbox" name="activate" ${linked?.active ? "" : "checked"}> Activate the scene now</label>
    </div>`;
    const syncVisibility = (root) => {
      const form = root?.querySelector?.("form") ?? root;
      const box = root?.querySelector?.(".atm-existing");
      if (!form || !box) return;
      const existing = form.querySelector('input[name="mode"]:checked')?.value === "existing";
      box.style.display = existing ? "" : "none";
    };
    const result = await DialogV2().wait({
      window: { title: "Atmosphere: first setup" },
      position: { width: 460 },
      content,
      render: (event, dialog) => {
        const root = dialog?.element ?? event?.target?.element;
        syncVisibility(root);
        root?.addEventListener("change", () => syncVisibility(root));
      },
      buttons: [
        { action: "run", label: "Set up Landing Page", icon: "fa-solid fa-wand-magic-sparkles", default: true,
          callback: (event, button) => {
            const f = button.form.elements;
            return { mode: f.mode.value, sceneId: f.sceneId?.value, resize: f.resize?.checked ?? true, backup: f.backup?.checked ?? true, activate: f.activate.checked };
          } },
        { action: "cancel", label: "Cancel" }
      ],
      rejectClose: false
    });
    if (!result || typeof result !== "object") return;
    try {
      const { scene, lockView, backupScene, resized } = await runSetup(result);
      ui.notifications.info(`Atmosphere: “${scene.name}” is ready as your Landing Page.`);
      if (backupScene) ui.notifications.info(`Backup saved as “${backupScene.name}”.`);
      if (resized?.convertedBackground) ui.notifications.info("The scene's map was kept in proportion by turning its background into a locked tile.");
      if (lockView === "ok") ui.notifications.info("Lock View configured. Make sure your players are enabled in Lock View's User Configurator.", { permanent: true });
      else ui.notifications.warn("Lock View is not active: pan/zoom locks were not set.");
    } catch (err) {
      console.error(`${ID} | setup failed`, err);
      ui.notifications.error("Atmosphere: setup failed. See the console (F12).");
    }
    this.render();
  }
}

/* ------------------------------------------------------------------ */
/* Hooks                                                               */
/* ------------------------------------------------------------------ */

Hooks.once("init", () => {
  const world = (key, type, def) => game.settings.register(ID, key, { scope: "world", config: false, type, default: def });
  const client = (key, type, def) => game.settings.register(ID, key, { scope: "client", config: false, type, default: def });
  world("rootSource", String, "data");
  world("rootPath", String, "");
  world("rootOptions", Object, {});
  world("tileUuid", String, "");
  world("favorites", Array, []);
  world("recent", Array, []);
  world("fadeMs", Number, 1000);
  client("expanded", Array, []);
  client("windowPos", Object, {});

  game.keybindings.register(ID, "open", {
    name: "Open Atmosphere Switcher",
    editable: [],
    restricted: true,
    onDown: () => { AtmosphereApp.toggle(); return true; }
  });

  const exts = CONST.IMAGE_FILE_EXTENSIONS;
  if (exts && typeof exts === "object") IMAGE_EXT = new Set(Object.keys(exts).map((e) => e.toLowerCase()));
});

Hooks.once("ready", () => {
  game.socket.on(SOCKET, (msg) => {
    if (msg?.type === "fadeOut") Fader.fadeOut(msg);
  });
  game.modules.get(ID).api = { open: () => AtmosphereApp.toggle(), show: showImage, setup: runSetup };
});

Hooks.on("getSceneControlButtons", (controls) => {
  if (!game.user?.isGM) return;
  const tool = {
    name: "atmosphere",
    title: "Atmosphere",
    icon: "fa-solid fa-image",
    button: true,
    visible: true,
    onChange: () => AtmosphereApp.toggle(),
    onClick: () => AtmosphereApp.toggle()
  };
  if (Array.isArray(controls)) {
    const tokens = controls.find((c) => c.name === "token");
    if (tokens) tokens.tools.push(tool);
    return;
  }
  const tokens = controls.tokens ?? controls.token;
  if (!tokens?.tools) return;
  tool.order = Object.keys(tokens.tools).length;
  delete tool.onClick;
  tokens.tools.atmosphere = tool;
});

Hooks.on("updateTile", (doc, changes, options) => {
  if (!doc.getFlag(ID, "atmosphere")) return;
  if (!foundry.utils.hasProperty(changes, "texture.src")) return;
  const fade = options?.[ID]?.fade ?? 0;
  if (Fader.states.has(doc.id)) Fader.fadeIn(doc.id, fade || 1000);
  if (AtmosphereApp.instance?.rendered) AtmosphereApp.instance.render();
});

Hooks.on("refreshTile", (tile) => {
  if (Fader.states.has(tile.document?.id)) Fader.apply(tile.document.id);
});

Hooks.on("canvasTearDown", () => {
  for (const id of [...Fader.states.keys()]) Fader.finish(id);
});
